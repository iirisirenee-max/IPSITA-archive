import React from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

type Entry = {
  id: string;
  title: string;
  parentId: string | null;
  category: string;
  type?: string;
  status?: string;
  description?: string;
  tags?: string[];
};

const entries: Entry[] = [
  {id:"ipsita",title:"IPSITA",parentId:null,category:"Root",type:"root",description:"An index of things made, found, learned & imagined."},
  ...["Literature","Research","Code","Design","Art","Archive","Presentations","Music"].map(x=>({id:x.toLowerCase(),title:x.toUpperCase(),parentId:"ipsita",category:x,type:"category",description:x==="Music"?"A future branch for singing, listening, performances and recordings.":undefined})),
  {id:"poetry",title:"Poetry",parentId:"literature",category:"Literature",type:"collection"},
  {id:"stories",title:"Stories",parentId:"literature",category:"Literature",type:"collection"},
  {id:"articles",title:"Articles",parentId:"literature",category:"Literature",type:"collection"},
  {id:"letters",title:"Letters",parentId:"literature",category:"Literature",type:"collection"},
  {id:"books",title:"Books",parentId:"literature",category:"Literature",type:"collection"},
  {id:"poems",title:"Poems",parentId:"poetry",category:"Literature",type:"collection"},
  {id:"poetry-competitions",title:"Poetry Competitions",parentId:"poetry",category:"Literature",type:"collection",description:"Competition contexts and their connected records."},
  {id:"poetry-certificate",title:"Participation certificate — details pending",parentId:"poetry-competitions",category:"Archive",type:"record",status:"Placeholder",description:"Reserved for the exact certificate wording and asset."},
  {id:"self-published",title:"Self-published · 0 currently",parentId:"books",category:"Literature",type:"record",description:"No self-published books are currently recorded."},
  {id:"collab",title:"Collaborative / Anthology Books",parentId:"books",category:"Literature",type:"collection"},
  {id:"collab-done",title:"Title pending",parentId:"collab",category:"Literature",type:"record",status:"Completed",description:"One completed collaborative or anthology book."},
  {id:"collab-next",title:"Upcoming title",parentId:"collab",category:"Literature",type:"record",status:"Upcoming",description:"One upcoming collaborative or anthology book."},
  {id:"research-fields",title:"Fields",parentId:"research",category:"Research",type:"collection"},
  {id:"space",title:"Space Science",parentId:"research-fields",category:"Research",type:"collection"},
  {id:"exoplanets",title:"Exoplanets",parentId:"space",category:"Research",type:"collection"},
  {id:"kepler",title:"NASA Kepler data exploration",parentId:"exoplanets",category:"Research",type:"project",status:"Exploration",description:"Computational exploration of exoplanet data."},
  {id:"infrastructure",title:"Infrastructure",parentId:"research-fields",category:"Research",type:"collection"},
  {id:"hazards",title:"Infrastructure hazard mapping",parentId:"infrastructure",category:"Research",type:"project",description:"Geospatial research direction around infrastructure hazards."},
  {id:"c",title:"C",parentId:"code",category:"Code",type:"collection"},
  {id:"code-projects",title:"Projects / Experiments",parentId:"c",category:"Code",type:"collection"},
  {id:"websites",title:"Websites",parentId:"code",category:"Code",type:"collection"},
  {id:"apps",title:"Apps",parentId:"code",category:"Code",type:"collection"},
  {id:"canva",title:"Canva",parentId:"design",category:"Design",type:"collection"},
  {id:"posters",title:"Posters",parentId:"canva",category:"Design",type:"collection"},
  {id:"presentations-design",title:"Presentations",parentId:"canva",category:"Design",type:"collection"},
  {id:"drawing",title:"Drawing",parentId:"art",category:"Art",type:"collection"},
  {id:"painting",title:"Painting",parentId:"art",category:"Art",type:"collection"},
  {id:"digital",title:"Digital Art",parentId:"art",category:"Art",type:"collection"},
  {id:"participation",title:"Participation",parentId:"archive",category:"Archive",type:"collection"},
  {id:"competitions",title:"Competitions",parentId:"archive",category:"Archive",type:"collection"},
  {id:"certificates",title:"Certificates",parentId:"archive",category:"Archive",type:"collection"},
  {id:"nsss",title:"NSSS 2025 Youth Outreach Programme",parentId:"participation",category:"Archive",type:"record",status:"Participation",description:"Participation record; exact certificate wording can be attached later."},
  {id:"presentation-projects",title:"Presentation Projects",parentId:"presentations",category:"Presentations",type:"collection"},
  ...["ALEATOR","ISREYA","IDORA","SPACE-AID","NEXUS GATE","MORPH CITY — THE CIVIC YARD"].map(x=>({id:x.toLowerCase().replace(/[^a-z0-9]+/g,"-"),title:x,parentId:"presentation-projects",category:"Presentations",type:"project",description:"Project node. Context and materials can be added later."})),
  {id:"singing",title:"Singing",parentId:"music",category:"Music",type:"collection",description:"Future music archive branch."},
  {id:"listening",title:"Listening",parentId:"music",category:"Music",type:"collection",description:"Future listening branch; Spotify can be connected later."},
  {id:"performances",title:"Performances",parentId:"music",category:"Music",type:"collection"},
  {id:"recordings",title:"Recordings",parentId:"music",category:"Music",type:"collection"},
];

const byId = new Map(entries.map(e=>[e.id,e]));
const children = (id:string) => entries.filter(e=>e.parentId===id);

function App(){
  const [expanded,setExpanded] = React.useState(new Set(["ipsita"]));
  const [selected,setSelected] = React.useState("ipsita");
  const [query,setQuery] = React.useState("");
  const [indexMode,setIndexMode] = React.useState(false);

  const visible = entries.filter(e=>{
    if(e.id==="ipsita") return true;
    let p=e.parentId;
    while(p){
      if(!expanded.has(p)) return false;
      p=byId.get(p)?.parentId ?? null;
    }
    return true;
  });

  const toggle=(id:string)=>{
    setExpanded(prev=>{const n=new Set(prev); n.has(id)?n.delete(id):n.add(id); return n;});
    setSelected(id);
  };

  const filtered = entries.filter(e=>(e.title+" "+e.category+" "+(e.description||"")).toLowerCase().includes(query.toLowerCase()));

  const selectedEntry=byId.get(selected)!;

  return <main>
    <header className="top">
      <div>
        <div className="eyebrow">IPSITA — LIVING INDEX</div>
        <h1>Everything I’ve<br/><i>explored.</i></h1>
        <p>An index of things made, found, learned & imagined.</p>
      </div>
      <div className="controls">
        <button className={!indexMode?"active":""} onClick={()=>setIndexMode(false)}>MAP</button>
        <button className={indexMode?"active":""} onClick={()=>setIndexMode(true)}>INDEX</button>
      </div>
    </header>

    {indexMode ? <section className="index">
      <div className="search"><input placeholder="search the archive…" value={query} onChange={e=>setQuery(e.target.value)}/></div>
      <div className="rows">{filtered.map(e=><button className="row" key={e.id} onClick={()=>{setSelected(e.id);setIndexMode(false)}}><span>{e.category}</span><strong>{e.title}</strong><small>{e.status||e.type||"—"}</small></button>)}</div>
    </section> : <section className="universe">
      <div className="grid"></div>
      <div className="orbit o1"></div><div className="orbit o2"></div>
      <div className="root-node" onClick={()=>toggle("ipsita")}>IPSITA<span>01</span></div>
      {visible.filter(e=>e.id!=="ipsita").map((e,i)=>{
        const isCat=e.parentId==="ipsita";
        const angle=[-155,-112,-68,-24,22,66,112,158][i%8];
        const radius=isCat?230:145;
        const x=Math.cos(angle*Math.PI/180)*radius;
        const y=Math.sin(angle*Math.PI/180)*radius;
        return <button key={e.id} className={"node "+(isCat?"category":"")} style={{"--x":`${x}px`,"--y":`${y}px`} as React.CSSProperties} onClick={()=>toggle(e.id)}>
          <span>{e.title}</span>{children(e.id).length>0&&<em>{children(e.id).length}</em>}
        </button>
      })}
    </section>}

    <aside className="inspector">
      <div className="eyebrow">INSPECTOR / {selectedEntry.category.toUpperCase()}</div>
      <h2>{selectedEntry.title}</h2>
      {selectedEntry.status&&<label>{selectedEntry.status}</label>}
      <p>{selectedEntry.description||"A branch in the living archive."}</p>
      <div className="meta">{selectedEntry.type||"entry"} · {children(selectedEntry.id).length} child node{children(selectedEntry.id).length===1?"":"s"}</div>
      {children(selectedEntry.id).length>0&&<div className="children">{children(selectedEntry.id).map(c=><button key={c.id} onClick={()=>toggle(c.id)}>{c.title}<span>↗</span></button>)}</div>}
    </aside>

    <footer><span>ARCHIVE / 2026 → ∞</span><a href="mailto:ipsitadebashreet@gmail.com">ipsitadebashreet@gmail.com</a><button onClick={()=>{}}>MUSIC: OFF</button></footer>
  </main>
}

createRoot(document.getElementById("root")!).render(<App />);
